$("body").click(function() {
  alert("clicou body");
});
